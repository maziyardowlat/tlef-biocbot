# ubc-genai-toolkit-encryption

Application-layer, field-level encryption for MongoDB.

Selected values are encrypted **before** they are sent to MongoDB and decrypted
**after** they are read back by an authorized application. Your code keeps
working with plaintext; the database only ever holds ciphertext for the fields
you declare.

```js
const { createEncryptedDb } = require('ubc-genai-toolkit-encryption');
const encryptionConfig = require('./encryption.config.js');

const protectedDb = await createEncryptedDb(db, encryptionConfig);

const notes = protectedDb.collection('sample_private_notes');
await notes.insertOne({ courseId: 'SAMPLE-101', body: 'a private note' });

const found = await notes.findOne({ courseId: 'SAMPLE-101' });
found.body; // 'a private note'
```

What MongoDB actually stores for `body`:

```js
{
  __ubc_enc: 1,
  alg: 'A256GCM',
  kid: 'data-2026-01',
  iv:  Binary(12 bytes),
  tag: Binary(16 bytes),
  ct:  Binary(...)
}
```

---

## Table of contents

- [What this protects, and what it does not](#what-this-protects-and-what-it-does-not)
- [Installation](#installation)
- [Quick start](#quick-start)
- [How it works](#how-it-works)
- [Configuration](#configuration)
- [Blind indexes: searching without storing the value](#blind-indexes-searching-without-storing-the-value)
- [Supported and unsupported operations](#supported-and-unsupported-operations)
- [Rollout policies](#rollout-policies)
- [Migrating existing data](#migrating-existing-data)
- [Key management and rotation](#key-management-and-rotation)
- [Benchmarking](#benchmarking)
- [What bypasses this toolkit](#what-bypasses-this-toolkit)
- [Inspecting raw MongoDB safely](#inspecting-raw-mongodb-safely)
- [Errors](#errors)
- [Logging and metrics](#logging-and-metrics)
- [Development](#development)
- [Documentation index](#documentation-index)

---

## What this protects, and what it does not

> **A person with only MongoDB access cannot decrypt protected fields. A person
> who compromises both the authorized application and the required encryption
> keys may decrypt them, because the application must possess those keys to use
> the data.**

That sentence is the whole security model. Everything below is detail.

**Protected** — for the fields you configure:

| Threat                                                                                 | Why it fails                                           |
| -------------------------------------------------------------------------------------- | ------------------------------------------------------ |
| Someone obtains the connection string or a database user                               | The values are ciphertext; the keys are not in MongoDB |
| Someone browses the data in Compass, `mongosh`, or a driver                            | Same                                                   |
| A `mongodump` or logical backup is copied                                              | Same                                                   |
| A data directory or storage snapshot is copied                                         | Same                                                   |
| Raw documents leak accidentally (a log, a screenshot, an export of the raw collection) | Same                                                   |
| Someone tampers with ciphertext, the IV, the tag, the key id, or the context           | Authentication fails; nothing is returned              |
| Someone moves a valid value to another namespace, collection, or field                 | Authentication fails; the context is signed            |

**Not protected** — this is not a gap in the implementation, it is the shape of
the problem:

- Compromise of **both** the application runtime and its key provider.
- Application behaviour that legitimately returns plaintext to the wrong user.
  Encryption does not do authorization.
- Plaintext in application logs, traces, metrics, caches, exports, or calls to
  third parties.
- Memory inspection of a process that is actively decrypting.
- Collections and fields you did not configure.
- Data copied somewhere else before it was encrypted.
- Equality and frequency analysis of blind-indexed values. See
  [blind indexes](#blind-indexes-searching-without-storing-the-value).

This package is **not** a replacement for TLS, database authentication and
authorization, disk encryption, backup security, or secret management. It is a
layer on top of all of them.

See [docs/threat-model.md](docs/threat-model.md) for the full analysis.

---

## Installation

```bash
npm install ubc-genai-toolkit-encryption
```

- Node.js 18 or newer.
- `mongodb` 6.x is a **peer dependency** — the toolkit wraps the driver instance
  your application already has. Install it yourself:

  ```bash
  npm install mongodb
  ```

- Works from CommonJS (`require`) and ships TypeScript declarations. TypeScript
  consumers also need `@types/node`, because the declarations reference
  `node:buffer` and `node:stream`.
- The only runtime dependency is `bson`.
- The package also installs a CLI, `ubc-genai-encryption`, used for migration
  and verification of existing data.

---

## Quick start

### 1. Generate two independent keys

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
```

Run it **twice**: once for the data-encryption key, once for the blind-index
key. They must be different from each other, and different from any key your
application already uses for something else (such as encrypting LLM API
credentials). Reusing a key means one compromise breaks two systems.

Store them wherever your deployment stores secrets — an injected secret file or
an institutional secret manager — **separately from your MongoDB credentials and
separately from your database backups**. A backup that contains both the data and
the key protects nothing.

### 2. Declare what to protect

`encryption.config.js`, in your application:

```js
const { defineEncryptionConfig, EnvironmentKeyProvider } = require('ubc-genai-toolkit-encryption');

module.exports = defineEncryptionConfig({
  namespace: 'sample-learning-app',

  keyProvider: new EnvironmentKeyProvider({
    activeEncryptionKey: { id: 'data-2026-01', env: 'SAMPLE_DATA_ENCRYPTION_KEY' },
    decryptionKeys: [],
    blindIndexKeys: [{ id: 'lookup-2026-01', env: 'SAMPLE_BLIND_INDEX_KEY' }],
  }),

  readPolicy: 'mixed',
  queryPolicy: 'mixed',
  writePolicy: 'encrypted',

  collections: {
    sample_private_notes: {
      fields: {
        body: { encrypt: true },
        'messages.$[].content': { encrypt: true },
      },
    },
    sample_people: {
      fields: {
        email: {
          encrypt: true,
          blindIndex: {
            field: 'email__bidx',
            keyId: 'lookup-2026-01',
            normalize: 'email',
            unique: true,
          },
        },
      },
    },
  },

  database: { uriEnv: 'MONGODB_URI', databaseEnv: 'MONGODB_DB_NAME' },
});
```

`defineEncryptionConfig` validates the schema when the module loads, so a typo
fails at startup rather than during a request.

### 3. Wrap your database once

```js
const protectedDb = await createEncryptedDb(db, encryptionConfig);
```

Do this once, where you already build your `Db`, and pass `protectedDb` to the
rest of the application. There are no `encrypt()`/`decrypt()` calls to sprinkle
through routes and services.

Collections you did not configure come back as ordinary driver collections with
unchanged behaviour.

### 4. Migrate what is already stored

New writes are encrypted from the moment you deploy. Existing rows are not.

```bash
npx ubc-genai-encryption plan     --config ./encryption.config.js --all-configured
npx ubc-genai-encryption migrate  --config ./encryption.config.js --collection sample_people --dry-run
npx ubc-genai-encryption migrate  --config ./encryption.config.js --collection sample_people --backup-confirmed --verify
```

Follow [docs/migration-runbook.md](docs/migration-runbook.md) rather than
improvising: the order of the steps is what makes the rollout reversible.

---

## How it works

### AES-256-GCM

Each value is encrypted with **AES-256** in **GCM** mode, using Node's built-in
`node:crypto`. No cryptography is implemented in this package.

GCM is an _authenticated_ mode: as well as making the value unreadable, it
produces a 16-byte **authentication tag** that is checked on every decryption. If
even one bit of the ciphertext changed, the tag does not verify and decryption
fails. You never get back a value that was altered in the database.

### A fresh IV per value

An **IV** (initialization vector) is a 12-byte random number generated
independently for every single encrypted value. It is what makes two identical
values encrypt to two different ciphertexts. Without it, an observer could see
that two students share an answer just by comparing stored bytes.

The IV is not secret and is stored next to the ciphertext. Reusing one _would_ be
a serious flaw, so the toolkit generates one per value, per write, always — and
there is a test that asserts it.

### Key ids

Every envelope records **which** key encrypted it (`kid: 'data-2026-01'`), never
the key itself. That is what makes rotation possible: old values keep naming the
old key, and the key provider is asked for exactly that key. A missing key id
raises `KeyNotFoundError` — the toolkit never tries other keys hoping one works.

### Authenticated context (AAD)

**AAD** is data that is not encrypted but _is_ covered by the authentication tag.
Version 1 signs:

```text
ubc-genai-toolkit-encryption
envelope-version=1
algorithm=A256GCM
namespace=<your application namespace>
collection=<collection name>
field=<canonical configured field path>
key-id=<encryption key id>
```

The practical effect: a value encrypted for `sample_people.email` cannot be
pasted into `sample_people.profile.displayName`, into another collection, or into
another application's namespace. It will fail to decrypt. An attacker with write
access to MongoDB cannot shuffle ciphertext between fields to change what your
application believes.

The document `_id` is deliberately **not** part of the AAD. Including it would
make it impossible to encrypt before an insert assigns an id, would force a read
before every update, and would break legitimate id changes during a migration.
The tradeoff: someone with write access could move a ciphertext between documents
of the _same_ collection and field. They still cannot read it — and they could
equally have copied the whole document.

### BSON type preservation

Before encryption, the value is wrapped and serialized as BSON:

```js
BSON.serialize({ value: originalValue });
```

and recovered with `BSON.deserialize(plaintext).value`. That is why a `Date`
comes back as a `Date`, an `ObjectId` as an `ObjectId`, and an embedded document
as an embedded document — rather than everything degrading to strings. Values the
BSON serializer cannot represent are rejected _before_ any write is attempted.

---

## Configuration

The toolkit owns the mechanics. **Your application owns the policy**: which
collections, which fields, which of them need lookup, and when to roll out. There
is no default namespace, no default key, no collection wildcard, and no
"encrypt every string" mode — by design.

### Field paths

| Form                              | Meaning                                                |
| --------------------------------- | ------------------------------------------------------ |
| `email`                           | a top-level field                                      |
| `profile.displayName`             | a nested field                                         |
| `messages.$[].content`            | `content` in **every** element of the `messages` array |
| `groups.$[].messages.$[].content` | nested arrays                                          |
| `tags.$[]`                        | every element of a scalar array                        |

`$[]` is the only wildcard. Numeric indexes (`messages.0.content`), positional
`$`, `$[identifier]`, `*`, and globs are rejected: a configured path describes a
_shape_, and pinning one position would silently leave the rest unprotected.

Also rejected: encrypting `_id`, configuring both a parent and its descendant,
two fields sharing one blind-index target, a blind index on a `$[]` path, and
path segments named `__proto__`, `constructor`, `prototype`, or `__ubc_enc`.

### Field options

```js
'profile.studentNumber': {
  encrypt: true,          // required; omit the field rather than setting false
  encryptNull: false,     // default: a null stays a plaintext null
  blindIndex: {           // optional; enables equality lookup
    field: 'profile.studentNumber__bidx',
    keyId: 'lookup-2026-01',
    normalize: 'trim',    // exact | trim | lowercase | email | your function
    unique: false,
    sparse: true,
  },
}
```

Null handling is worth stating plainly: a missing path stays missing, and a
`null` stays a plaintext `null` unless you set `encryptNull: true`. A null
discloses no value and keeps `$exists` and `{ field: null }` queries working.
Empty strings and empty arrays _are_ real values and are always encrypted.

Full reference: [docs/configuration.md](docs/configuration.md).

---

## Blind indexes: searching without storing the value

Encrypting `email` means `findOne({ email })` can no longer work — the stored
bytes are different every time. A **blind index** restores exactly one capability:
equality lookup.

The value is normalized (for example lowercased), then run through
**HMAC-SHA-256** with a separate key, and the digest is stored in a sibling
field:

```text
email__bidx: "bi1:lookup-2026-01:5rSPDQ0mMLdxq5Y2v0hnhkYtY8m3JhrCrRVBUB9bTZo"
```

`findOne({ email: 'learner@example.invalid' })` is rewritten automatically to
match that digest. Your application code does not change.

**What it leaks, and why you must think about it.** The same value always
produces the same digest. Someone with database access cannot reverse a digest
without the key, but they _can_ see which documents share a value and count how
often each distinct value occurs.

For a high-cardinality identifier like an email address that is usually
acceptable. For a low-cardinality field — a role, a boolean, a five-value status
— it is not: an observer counts the groups and labels them by size. **Do not
blind-index low-cardinality values.**

Version 1 stores the full 32-byte digest (never truncated) and normalizes
conservatively: `email` trims and lowercases, and deliberately does _not_ fold
dots or plus-addressing, because doing so would silently change which values
collide.

---

## Supported and unsupported operations

Full matrix: [docs/supported-operations.md](docs/supported-operations.md).

**Writes** — `insertOne`, `insertMany`, `replaceOne`, `updateOne`,
`findOneAndUpdate`, `findOneAndReplace`, `findOneAndDelete`, `deleteOne`,
`deleteMany`, `bulkWrite` containing `insertOne`/`replaceOne`/`updateOne`, and
standalone `updateMany` _when it stays clear of configured fields_. Update operators on protected fields: `$set`, `$setOnInsert`, `$unset`,
and `$push` (including `$each`). `$addToSet` is rejected for values containing
encrypted descendants because fresh random IVs make equal plaintext values
unequal at the storage layer.

**Reads** — `findOne`, `find` with full cursor support (`next`, `tryNext`,
`hasNext`, `toArray`, `forEach`, `for await`, `stream`, `map`, and chained
`sort`/`limit`/`skip`/`project`/`batchSize`/`hint`/`collation`/`maxTimeMS`),
`countDocuments`, `estimatedDocumentCount`, `distinct` on plaintext fields, and
a restricted `aggregate`.

**Rejected before reaching MongoDB**, each with a typed error:

| You wrote                                                | Why it cannot work                                                                             |
| -------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `{ body: { $regex: /x/ } }`, `$gt`, `$lt`, `$ne`, `$nin` | Ciphertext has no order and no substrings                                                      |
| `{ email: 'x' }` with no blind index                     | Nothing to match against; add a blind index or use `$exists`                                   |
| `sort({ body: 1 })`                                      | Would order by ciphertext, not by the value                                                    |
| `projection: { 'body.ct': 1 }`                           | Returns a fragment of an envelope that can never be decrypted                                  |
| `updateMany` touching a protected field                  | One ciphertext would be copied into every matched document, destroying per-value IV uniqueness |
| Update pipelines (`[{ $set: … }]`)                       | A pipeline computes from the stored value, which is ciphertext                                 |
| `$addToSet` with encrypted descendants                   | Randomized ciphertext cannot preserve plaintext set equality                                   |
| `$group`, `$lookup`, `$unwind`, `$addFields`, …          | Cannot be proven safe over encrypted paths                                                     |
| Writing an envelope yourself                             | Prevents pasting someone else's ciphertext into your own record                                |

Failing loudly is the point. The alternative — running the query anyway — returns
wrong results that look right.

---

## Rollout policies

Three independent switches let you deploy in stages instead of all at once.

| Policy        | Values                      | Meaning                                                                                                                                                                           |
| ------------- | --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `readPolicy`  | `mixed` → `strict`          | `mixed` decrypts envelopes and passes plaintext through, for the period when both exist. `strict` rejects any plaintext in a configured field with `PlaintextValueRejectedError`. |
| `queryPolicy` | `mixed` → `encrypted`       | `mixed` matches _either_ the blind index _or_ the legacy plaintext field, so lookups work mid-migration. `encrypted` queries only the blind index.                                |
| `writePolicy` | `encrypted` / `passthrough` | `passthrough` writes plaintext and exists only for baseline benchmarking and staged reader deployment. It logs a warning once.                                                    |

Both `mixed` modes are **temporary**. They exist so that a rollout can be
interrupted or reversed safely. Move to `strict` + `encrypted` once verification
passes; that is what turns "we encrypt new data" into "there is no plaintext
left". Note that malformed envelopes and authentication failures are rejected in
_every_ mode — `mixed` tolerates plaintext, never corruption.

---

## Migrating existing data

The CLI is a supported part of the package, not an example script.

```bash
npx ubc-genai-encryption <command> --config ./encryption.config.js
```

| Command          | What it does                                                                                                        |
| ---------------- | ------------------------------------------------------------------------------------------------------------------- |
| `plan`           | Read-only. Counts plaintext, envelopes, malformed values, digests, key ids, and relevant indexes. Prints no values. |
| `status`         | Checkpoints, leases, counts, errors by code, verification state.                                                    |
| `ensure-indexes` | Creates the configured blind indexes. Never drops an existing index.                                                |
| `migrate`        | Encrypts configured plaintext and generates digests. Resumable, idempotent, lease-protected.                        |
| `verify`         | Authenticates and decrypts every configured value and recomputes every digest.                                      |
| `rotate`         | Re-encrypts existing envelopes under the active key.                                                                |
| `decrypt`        | Guarded reverse migration. Requires `--dry-run=false` **and** `--confirm-plaintext-output`.                         |
| `benchmark`      | Runs your workloads against plaintext and encrypted modes.                                                          |

Safety properties, all covered by tests against a real MongoDB:

- **Idempotent** — a value already in its target state is skipped; a rerun
  changes nothing.
- **Resumable** — documents are traversed in ascending `_id` order and the
  checkpoint advances only after every document in a batch is written or safely
  classified.
- **Lease-protected** — two migrators cannot touch one collection at once, and a
  crashed migrator's lease expires and is recoverable.
- **Safe against live writes** — every write is conditional on the exact values
  that were read. If your application updated the document in between, the write
  does not match; the document is re-read and retried, and after bounded retries
  it is recorded as a conflict rather than overwritten with stale data.
- **Single-document atomicity** — encrypted values and their digests land in one
  update. No multi-document transaction is required.
- **Backup-gated** — any command that writes requires `--backup-confirmed`.
- **Quiet** — checkpoints, logs, reports, and errors carry counts, paths, key
  ids, and _encoded_ document ids. Never values.

Exit codes are stable within a major version:

| Code | Meaning                                                         |
| ---- | --------------------------------------------------------------- |
| `0`  | Completed; verification passed if requested                     |
| `1`  | Configuration or preflight failure — nothing was written        |
| `2`  | Migration or verification found a data failure                  |
| `3`  | Lease or concurrency conflict                                   |
| `4`  | Interrupted before completion; completed progress was persisted |

On `SIGINT`/`SIGTERM` the run finishes its current operation, persists only fully
completed progress, releases the lease, closes the client and key provider, and
exits `4`.

### Rolling back

**Turning off encrypted writes is not a rollback.** Data already encrypted stays
encrypted. Your three real options are:

1. Keep `readPolicy: 'mixed'` deployed so both forms are readable.
2. Run the guarded `decrypt` command, which writes authenticated plaintext back —
   and puts that plaintext into every subsequent backup.
3. Restore a pre-migration backup.

Plan which one you would use _before_ you migrate.

---

## Key management and rotation

Keys are never stored in MongoDB, never embedded in configuration, never accepted
as CLI flags, and never written to logs, metrics, checkpoints, reports, or error
messages. The CLI has no `--key` option and never will.

Two providers ship with the package:

- `EnvironmentKeyProvider` — configuration names the environment _variables_;
  values are read once, validated, and cached. Accepts 32-byte keys as canonical
  base64, base64url, or 64-character hexadecimal, and rejects PEM/OpenSSH key
  documents outright so an RSA key file cannot be mistaken for an AES key.
- `StaticKeyProvider` — explicit buffers, for tests and tightly controlled
  programmatic use.

The `KeyProvider` interface is three methods, so Vault, a cloud KMS, or an
institutional secret manager can be added later without touching anything else:

```ts
interface KeyProvider {
  getActiveEncryptionKey(): Promise<EncryptionKeyRecord>;
  getEncryptionKey(id: string): Promise<EncryptionKeyRecord | null>;
  getBlindIndexKey(id: string): Promise<BlindIndexKeyRecord | null>;
}
```

**Rotating a key**, in order: add the new key as `activeEncryptionKey` while
keeping the old one in `decryptionKeys`; deploy; run `rotate --from-key-id
<old>`; run `verify`; confirm no envelope still names the old key; only then
remove it from the provider. Blind indexes are never rotated as a side effect —
they have their own key and their own lifecycle.

Details: [docs/key-management.md](docs/key-management.md).

---

## Benchmarking

A generic crypto microbenchmark tells you nothing useful. What matters is what
happens to _your_ queries with _your_ documents and _your_ indexes, so the runner
takes workloads you write and runs them against both a raw `Db` and a protected
`Db`.

It reports operation count, throughput, p50/p95/p99 latency, errors by category,
CPU and memory deltas, collection and index sizes before and after, and the
environment. The runner refuses to start without an explicit confirmation that
the target database holds synthetic data.

The toolkit does **not** publish a universal overhead figure. It flags a workload
for review when p95 latency rises more than 15%, when the encrypted mode produces
more errors, or when index size grows unexpectedly. Whether that is acceptable is
your application's decision, not the toolkit's.

See [examples/benchmark.example.cjs](examples/benchmark.example.cjs) and
[docs/benchmarking.md](docs/benchmarking.md).

---

## What bypasses this toolkit

Encryption applies to configured fields written through the protected `Db`.
Everything below reaches your data another way, and this package does not cover
it:

- **`getRawDb()` / `getRawCollection()`** — off by default; requires
  `allowRawAccess: true`; bypasses every guarantee by design.
- **GridFS** — stream encryption is a separate feature, not in version 1.
- **`connect-mongo` sessions** — session documents are written by that library,
  not by this wrapper.
- **Change streams** — deliver raw documents; rejected on protected collections
  rather than silently handing you envelopes.
- **Vector stores (Qdrant and similar)** — payloads you copy there are outside
  this package entirely.
- **Logs, traces, metrics, caches, exports, and third-party calls** — if your
  code logs the plaintext it just decrypted, it is in the log.
- **Unconfigured collections and fields** — nothing implicit is protected.

If sensitive data flows anywhere in that list, inventory it _before_ you migrate,
not after.

---

## Inspecting raw MongoDB safely

Looking at protected data in Compass or `mongosh` is expected and useful — just
know what you are looking at:

- A configured field showing `{ __ubc_enc: 1, alg: 'A256GCM', … }` is correctly
  encrypted.
- A configured field showing a readable value has not been migrated yet, or was
  written while `writePolicy` was `passthrough`.
- A `*__bidx` field is an HMAC digest, not the value, and not reversible without
  the blind-index key.
- You cannot decrypt anything from the shell, and neither can anyone else with
  the same access. That is the point.

Use `plan` and `verify` rather than eyeballing collections — they classify every
value and print counts without printing data.

---

## Errors

Every error is typed and carries a stable `code`. Errors may include the
namespace, collection, configured path, operation, key id, and an _encoded_
document id; they never include plaintext, keys, ciphertext, IVs, tags, digests,
raw documents, or environment values.

`ConfigurationError` · `KeyNotFoundError` · `InvalidKeyError` ·
`EnvelopeValidationError` · `UnsupportedEnvelopeVersionError` ·
`AuthenticationFailedError` · `PlaintextValueRejectedError` ·
`ValueSerializationError` · `EncryptedFieldQueryNotSupportedError` ·
`EncryptedFieldSortNotSupportedError` · `EncryptedAggregationNotSupportedError` ·
`EncryptedProjectionNotSupportedError` · `EncryptedUpdateNotSupportedError` ·
`MultiDocumentEncryptedUpdateNotSupportedError` · `UnsupportedOperationError` ·
`MigrationConflictError` · `MigrationLeaseError` · `VerificationError`

```js
const { isEncryptionToolkitError } = require('ubc-genai-toolkit-encryption');

try {
  await people.findOne({ email: { $regex: '^a' } });
} catch (error) {
  if (isEncryptionToolkitError(error) && error.code === 'ENCRYPTED_FIELD_QUERY_NOT_SUPPORTED') {
    // Handle it, or fix the query.
  }
}
```

---

## Logging and metrics

Both adapters are optional, injected, and log _events, not values_:

```js
logger: { debug, info, warn, error },   // (message, context)
metrics: { increment, observe },        // low-cardinality labels only
```

Counters cover encrypt/decrypt operations, authentication failures, strict-mode
plaintext rejections, unsupported operations, and migration progress. A throwing
logger or metrics adapter can never fail a database operation.

---

## Development

```bash
npm install
npm run mongo:start        # disposable MongoDB replica set in Docker
npm run verify             # format, lint, typecheck, build, unit + security tests
npm run test:integration   # wrapper, migration, and CLI tests against real MongoDB
npm run coverage
npm run mongo:stop
```

Integration and migration tests run against a real MongoDB server, never a mocked
collection API: dot-notation array traversal, conditional-update matching, and
partial unique indexes are server behaviours, and mocking them would test the
mock. Security-critical modules (crypto, envelope, AAD, key validation) are held
to a higher coverage bar than the rest of the package.

```text
src/
  config/      schema types, path grammar, validation, fingerprint
  crypto/      AAD, envelope, AES-256-GCM, blind indexes, normalizers
  keys/        provider contract, environment and static providers
  mongo/       protected Db, collection, cursor, filter/update/projection/aggregation
  migration/   planner, runner, verifier, checkpoints, leases, indexes
  benchmark/   workload runner
  cli/         ubc-genai-encryption
  errors/      typed errors and redaction
```

---

## Documentation index

| Document                                                                         | Contents                                   |
| -------------------------------------------------------------------------------- | ------------------------------------------ |
| [docs/threat-model.md](docs/threat-model.md)                                     | What is and is not defended, and why       |
| [docs/configuration.md](docs/configuration.md)                                   | Every option, every validation rule        |
| [docs/key-management.md](docs/key-management.md)                                 | Generating, storing, and rotating keys     |
| [docs/supported-operations.md](docs/supported-operations.md)                     | The full operation matrix                  |
| [docs/migration-runbook.md](docs/migration-runbook.md)                           | Step-by-step rollout and rollback          |
| [docs/benchmarking.md](docs/benchmarking.md)                                     | Measuring and interpreting overhead        |
| [docs/releasing.md](docs/releasing.md)                                           | Publishing a new version to npm            |
| [examples/encryption.config.example.cjs](examples/encryption.config.example.cjs) | Annotated configuration                    |
| [examples/benchmark.example.cjs](examples/benchmark.example.cjs)                 | Synthetic workloads                        |
| [RELEASE-NOTES.md](RELEASE-NOTES.md)                                             | Supported operations and known limitations |

All examples use fabricated names (`sample-learning-app`, `sample_private_notes`,
`sample_people`) and synthetic values. They are illustrations, not defaults, and
must not be copied into a real application without a field and query audit of
that application.
