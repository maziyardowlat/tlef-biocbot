# Release notes

## 0.1.0 — unreleased

First release of `ubc-genai-toolkit-encryption`.

### What this release provides

- **Field-level encryption** using AES-256-GCM envelopes. Configured values are
  encrypted before they reach MongoDB and decrypted after an authorized read.
- **Blind indexes** (HMAC digests) for equality lookup and unique constraints on
  encrypted fields, without storing the searchable plaintext.
- **A transparent driver wrapper** — `createEncryptedDb(db, config)` returns a
  `Db` that your existing collection calls work against unchanged.
- **Migration tooling** for existing data: plan, run, verify, status, and index
  management, driven from the `ubc-genai-encryption` CLI.
- **A benchmark harness** for measuring the overhead the toolkit adds.
- **TypeScript declarations**, and CommonJS `require` support.

### Known limitations

These are design consequences of application-layer encryption, not defects. The
full matrix is in [docs/supported-operations.md](docs/supported-operations.md);
the security boundary is in [docs/threat-model.md](docs/threat-model.md).

- **Only equality queries** work against encrypted fields, and only through a
  configured blind index. Range (`$gt`, `$lt`), negation (`$ne`, `$nin`),
  regex, and text search on an encrypted field are rejected before they reach
  MongoDB rather than returning silently wrong results.
- **Blind indexes leak equality and frequency.** The same normalized value under
  the same key always produces the same digest. An attacker who reads the
  collection learns which documents share a value, and how often each value
  occurs.
- **`updateMany` is rejected** when it touches a configured field, because each
  document needs its own IV and envelope.
- **Update pipelines, `arrayFilters`, and positional paths** are rejected on
  configured fields.
- **`distinct`, sorting, and `createIndex`** on an encrypted path are rejected.
  Ciphertext does not sort in plaintext order.
- **Change streams (`watch`)** are not supported.
- **`$expr`, `$where`, and `$jsonSchema`** are rejected on any configured
  collection, because they cannot be analyzed for encrypted-field references.
- **Document `_id` is not part of the version 1 AAD.** This is deliberate — it
  permits encryption before insert and controlled ID changes during migration.
  The tradeoff is analyzed in [docs/threat-model.md](docs/threat-model.md).

### Requirements

- Node.js 18 or newer.
- `mongodb` 6.x, as a peer dependency.
- TypeScript consumers need `@types/node`; the published declarations reference
  `node:buffer` and `node:stream`.

### Security note

This package does not replace TLS, database authentication and authorization,
disk encryption, backup security, or secret management. It is a layer on top of
all of them. It does not protect against an attacker who holds both the
application and its keys.
