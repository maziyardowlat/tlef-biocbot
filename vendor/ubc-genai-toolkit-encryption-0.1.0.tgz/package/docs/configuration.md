# Configuration guide

The toolkit owns cryptography and MongoDB mechanics. Your application owns every
decision about _what_ is protected. This document is the complete reference.

## Where configuration lives

Put it in one module in your application, built with `defineEncryptionConfig`,
and pass the same module to `createEncryptedDb` and to the CLI's `--config`. The
CLI executes it with `require`, so treat its path like any other executable path.

`defineEncryptionConfig` validates when the module loads, so a bad schema fails
at startup rather than on the first request.

## Top-level options

### Required

| Option        | Type                               | Notes                                                                                                                                                          |
| ------------- | ---------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `namespace`   | `string`                           | Stable identifier, authenticated into every ciphertext. Must match `/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/`. **Changing it makes existing data undecryptable.** |
| `keyProvider` | `KeyProvider`                      | Supplies encryption and blind-index keys.                                                                                                                      |
| `readPolicy`  | `'mixed' \| 'strict'`              | How reads treat plaintext in a configured field.                                                                                                               |
| `queryPolicy` | `'mixed' \| 'encrypted'`           | How equality filters on blind-indexed fields are rewritten.                                                                                                    |
| `writePolicy` | `'encrypted' \| 'passthrough'`     | Whether writes encrypt.                                                                                                                                        |
| `collections` | `Record<string, CollectionConfig>` | Explicit map. No wildcards.                                                                                                                                    |

### Optional

| Option                        | Default                      | Notes                                                                                              |
| ----------------------------- | ---------------------------- | -------------------------------------------------------------------------------------------------- |
| `logger`                      | none                         | `{ debug, info, warn, error }`. Logs events, never values.                                         |
| `metrics`                     | none                         | `{ increment?, observe? }`. Low-cardinality labels only.                                           |
| `onUnsupportedOperation`      | none                         | Called with the typed error before it is thrown. Observability only; it cannot suppress the error. |
| `allowRawAccess`              | `false`                      | Enables `getRawDb()` / `getRawCollection()`, which bypass every guarantee.                         |
| `database`                    | none                         | Connection metadata for the CLI and programmatic tooling. Required for CLI commands.               |
| `migrationMetadataCollection` | `_ubc_encryption_migrations` | Checkpoint collection name. Cannot also be a protected collection.                                 |

### `database`

Consumed only by operational tooling. `createEncryptedDb` ignores it: it wraps the
`Db` your application already connected, and never opens a second client.

```js
database: { uriEnv: 'MONGODB_URI', databaseEnv: 'MONGODB_DB_NAME' }
```

or a trusted factory:

```js
database: {
  connect: async () => ({ client, db });
}
```

Exactly one of `uriEnv` or `connect` must be present. `uriEnv` must be the _name_
of an environment variable — a literal URI is rejected, because committing one to
source control is how credentials leak.

## Field paths

| Form                              | Meaning                                  |
| --------------------------------- | ---------------------------------------- |
| `email`                           | top-level field                          |
| `profile.displayName`             | nested field                             |
| `messages.$[].content`            | `content` in every element of `messages` |
| `groups.$[].messages.$[].content` | nested arrays                            |
| `tags.$[]`                        | every element of a scalar array          |

`$[]` is the only wildcard in version 1.

**Rejected, with the reason:**

| Rejected                                       | Why                                                                                                                |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `messages.0.content`                           | A numeric index protects one position and silently leaves the rest exposed.                                        |
| `messages.$.content`, `messages.$[el].content` | Positional operators are runtime constructs, not schema.                                                           |
| `messages.*.content`, globs                    | MongoDB would treat `*` as a literal field name, so the configuration would protect nothing while looking correct. |
| `$[].content`                                  | A document root is not an array.                                                                                   |
| `_id`                                          | The id is needed in plaintext for lookups, checkpoints, and resumption.                                            |
| `__proto__`, `constructor`, `prototype`        | Prototype-pollution shapes.                                                                                        |
| `__ubc_enc`                                    | Collides with the envelope discriminator.                                                                          |
| Paths containing a null byte                   | Would make the authenticated context ambiguous.                                                                    |

## Field options

```js
fields: {
  body: { encrypt: true },

  optionalNote: { encrypt: true, encryptNull: true },

  email: {
    encrypt: true,
    blindIndex: {
      field: 'email__bidx',
      keyId: 'lookup-2026-01',
      normalize: 'email',
      unique: true,
      sparse: true,
    },
  },
}
```

| Option        | Default | Notes                                                                                                   |
| ------------- | ------- | ------------------------------------------------------------------------------------------------------- |
| `encrypt`     | —       | Must be `true`. Omit the field rather than setting `false`, so a disabled field cannot look configured. |
| `encryptNull` | `false` | When false, an explicit `null` stays a plaintext `null`.                                                |
| `blindIndex`  | none    | Equality lookup. See below.                                                                             |

### Value handling

| Stored value                 | Behaviour                                                                                          |
| ---------------------------- | -------------------------------------------------------------------------------------------------- |
| Path missing                 | Stays missing. Nothing is created.                                                                 |
| `null`, `encryptNull: false` | Stays a plaintext `null`. It discloses no value and keeps `$exists` and `{ field: null }` working. |
| `null`, `encryptNull: true`  | Encrypted like any other value.                                                                    |
| `undefined`                  | Rejected with `ValueSerializationError`; it is never silently changed to `null` or omitted.        |
| `''`, `[]`, `{}`             | Real values. Always encrypted.                                                                     |
| Non-BSON-representable value | Rejected with `ValueSerializationError` before any write.                                          |

## Blind-index options

| Option      | Default   | Notes                                                                                                |
| ----------- | --------- | ---------------------------------------------------------------------------------------------------- |
| `field`     | —         | Required target path storing the digest. Conventionally `<source>__bidx`.                            |
| `keyId`     | —         | Required. Must be known to the key provider and must not contain `:`.                                |
| `normalize` | `'exact'` | `exact`, `trim`, `lowercase`, `email`, or a function.                                                |
| `unique`    | `false`   | Creates a unique index, always with a partial filter.                                                |
| `sparse`    | `true`    | Applied only when the index is not unique — MongoDB rejects `sparse` combined with a partial filter. |

### Built-in normalizers

| Name        | Behaviour                                                                                                                                                                |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `exact`     | The string exactly as supplied.                                                                                                                                          |
| `trim`      | Leading and trailing whitespace removed.                                                                                                                                 |
| `lowercase` | Trimmed, then lowercased without locale rules.                                                                                                                           |
| `email`     | Trimmed, then lowercased. **Nothing else**: dots, plus-addressing, and Unicode normalization are left alone, because folding them silently changes which values collide. |

All four reject non-string values with `ValueSerializationError`. For any other
type, supply a custom normalizer.

### Custom normalizers

```js
normalize: (value) => `student:${String(value).replace(/\s+/g, '')}`,
```

Must be synchronous, deterministic, and return a string or `Uint8Array`. It runs
in your application and in the CLI (which loads your configuration module).
Changing its behaviour changes every digest it produces, so existing indexes must
be regenerated. The schema fingerprint hashes the custom function's source text,
so changing its implementation also prevents an unsafe checkpoint resume.

## Validation rules

`validateEncryptionConfig` rejects all of the following before any database
operation. Messages name the collection and configured path, never a value.

**Top level:** empty or unstable namespace; a key provider missing any of the
three methods; unknown policy values; `queryPolicy: 'mixed'` combined with
`readPolicy: 'strict'` (the mixed query policy exists to match legacy plaintext,
which strict reads reject); non-object `collections`; an empty collection map
when an operational command requires one; a logger missing a method; non-object
metrics; a non-function hook; a non-boolean `allowRawAccess`; malformed
`database`.

**Collections:** empty names, names containing `$` or a null byte, `system.*`
names, reserved names, a collection that is also the migration metadata
collection.

**Fields:** a missing or non-`true` `encrypt`; unknown field options; non-boolean
`encryptNull`; any invalid path form above; a non-canonical spelling of a path; a
collection declaring no fields.

**Path relationships:** a parent and a descendant both configured
(`profile` and `profile.name`); two fields sharing one blind-index target; a
blind-index target overlapping any encrypted path; a blind index on a `$[]` path
(it must resolve to a single scalar per document).

**Blind indexes:** missing or non-string `field`; missing `keyId`; a `keyId`
containing `:` or a null byte; an unknown normalizer name; non-boolean `unique`
or `sparse`; a target path containing `$`, a null byte, or a reserved segment.

**Keys:** `assertKeysAvailable` additionally resolves the active encryption key
and every referenced blind-index key during initialization, so an unknown key id
fails before the first database operation.

## Schema fingerprint

Validation computes a stable fingerprint over the storage schema: namespace,
collections, field paths, `encryptNull`, and blind-index settings (including a
built-in identifier or custom-normalizer source hash). Rollout policies are not
part of the storage schema and do not change the fingerprint. It appears in `plan`, `status`,
migration checkpoints, and preflight output.

Its job is to catch a mismatch between a stored checkpoint and the configuration
in front of you: resuming a migration under a changed schema raises
`MigrationLeaseError` rather than producing half-migrated data.

## Worked example

See [examples/encryption.config.example.cjs](../examples/encryption.config.example.cjs).
Every name in it is fabricated. Do not copy it into a real application without
auditing that application's fields and queries — each field you protect is a
field you can no longer sort, range-query, or regex-search.
