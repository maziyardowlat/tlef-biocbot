# Releasing to npm

The package is published to the public npm registry as
`ubc-genai-toolkit-encryption`, matching the naming of the other UBC GenAI
Toolkit modules (`ubc-genai-toolkit-llm`, `-rag`, `-core`, and so on).

Publishing is effectively irreversible. A version number can never be reused,
and npm's unpublish window is 72 hours at most and only applies under narrow
conditions. Treat every publish as permanent.

## One-time setup

1. **Get publish access.** The existing `ubc-genai-toolkit-*` packages are
   maintained by `richtape` (richard.tape@ubc.ca). Ask to be added as a
   maintainer, or have that account run the first publish. The name
   `ubc-genai-toolkit-encryption` is currently unregistered, so whoever
   publishes 0.1.0 claims it.

2. **Enable 2FA on the npm account** and require it for publishing. This
   package encrypts institutional data; an account takeover that ships a
   malicious version reaches every consuming application.

3. **Log in:**

   ```bash
   npm login
   ```

   Confirm with `npm whoami`.

## Every release

1. **Confirm the version.** Update `version` in `package.json` and add a
   section to [RELEASE-NOTES.md](../RELEASE-NOTES.md). Pre-1.0, breaking
   changes go in the minor position (0.1.0 → 0.2.0).

2. **Run the full gate:**

   ```bash
   npm run verify
   ```

   Format check, lint, typecheck, build, and unit tests.

3. **Inspect what would ship:**

   ```bash
   npm run pack:inspect
   ```

   Fails if sources, tests, coverage, internal planning documents, or a
   credentialed connection string reach the tarball, and warns on any
   key-shaped string in shipped text. Read the warnings — an illustrative
   digest in the README is expected, real key material is not.

4. **Test the tarball as a consumer would:**

   ```bash
   npm run test:consumer
   ```

   Installs the packed tarball into a throwaway CommonJS application, checks
   the exported surface, blocks deep imports, runs an encrypt/decrypt round
   trip, compiles a TypeScript file against the published declarations, and
   runs the CLI shim. This is the only test that exercises what is actually
   published — the unit suite imports from `src/`, so it cannot catch a missing
   `files` entry or a broken `bin` path.

5. **Dry run the publish:**

   ```bash
   npm publish --dry-run
   ```

6. **Publish:**

   ```bash
   npm run release
   ```

   `prepack` rebuilds `dist/` from current sources, and `prepublishOnly` re-runs
   `verify` and the consumer fixture test. Neither runs on a plain
   `npm install`.

7. **Tag the commit:**

   ```bash
   git tag -a v0.1.0 -m "v0.1.0" && git push origin v0.1.0
   ```

8. **Verify the published package** from a clean directory:

   ```bash
   npm view ubc-genai-toolkit-encryption
   ```

## If something bad ships

Within 72 hours, `npm unpublish ubc-genai-toolkit-encryption@<version>` may
work. After that, deprecate instead and publish a fixed version:

```bash
npm deprecate ubc-genai-toolkit-encryption@<version> "Use <fixed version> instead"
```

If key material or a credential reached the registry, treat it as disclosed:
rotate the secret first, then deal with the package.
