# Supported operation matrix

Applies to **configured collections**. Collections that are not in the
configuration are returned as ordinary driver collections and behave exactly as
they always did.

Legend: ✅ supported · ⚠️ supported with limits · ❌ rejected before reaching
MongoDB, with a typed error.

## Writes

| Operation                                | Status | Notes                                                                                     |
| ---------------------------------------- | ------ | ----------------------------------------------------------------------------------------- |
| `insertOne`                              | ✅     | Configured values encrypted; digests generated.                                           |
| `insertMany`                             | ✅     | Each value encrypted independently — equal plaintext produces different ciphertext.       |
| `replaceOne`                             | ✅     | Replacement fully traversed; stale digests cleared.                                       |
| `updateOne`                              | ✅     | See the update-operator table.                                                            |
| `findOneAndUpdate`                       | ✅     | Returned document decrypted; result metadata shape preserved.                             |
| `findOneAndReplace`                      | ✅     | Same.                                                                                     |
| `findOneAndDelete`                       | ✅     | Returned document decrypted.                                                              |
| `deleteOne` / `deleteMany`               | ✅     | Filter rewritten; no decryption needed.                                                   |
| `bulkWrite`                              | ⚠️     | Only `insertOne`, `replaceOne`, and `updateOne`. Other bulk operation types are rejected. |
| `updateMany`                             | ⚠️     | Allowed **only** when the update cannot affect a configured or blind-index field.         |
| `updateMany` touching a configured field | ❌     | `MultiDocumentEncryptedUpdateNotSupportedError`                                           |
| Update pipelines (`[{ $set: … }]`)       | ❌     | `EncryptedUpdateNotSupportedError`                                                        |
| `arrayFilters`                           | ❌     | `EncryptedUpdateNotSupportedError`                                                        |
| A write containing an envelope           | ❌     | `EnvelopeValidationError`                                                                 |
| `watch` (change streams)                 | ❌     | `UnsupportedOperationError`                                                               |

### Why `updateMany` is rejected on protected fields

Encrypting the operand once would write a single IV and ciphertext into every
matched document, destroying the guarantee that every value has a unique IV and
making equal values visibly equal. Encrypting per document would mean reading and
writing each one separately — which is not what `updateMany` promises about
atomicity and concurrency. Update the documents individually instead.

## Update operators

| Operator                                                                                       | On a configured field                                          | Elsewhere                   |
| ---------------------------------------------------------------------------------------------- | -------------------------------------------------------------- | --------------------------- |
| `$set`                                                                                         | ✅ encrypts; refreshes the digest                              | ✅                          |
| `$setOnInsert`                                                                                 | ✅ same, on upsert                                             | ✅                          |
| `$unset`                                                                                       | ✅ also unsets the digest                                      | ✅                          |
| `$push`                                                                                        | ✅ encrypts each added element, including `$each`              | ✅                          |
| `$addToSet`                                                                                    | ❌ randomized envelopes cannot preserve plaintext set equality | ✅                          |
| `$push` with `$sort` on an encrypted subfield                                                  | ❌                                                             | —                           |
| `$inc`, `$mul`, `$min`, `$max`, `$rename`, `$pop`, `$pull`, `$pullAll`, `$bit`, `$currentDate` | ❌                                                             | ✅ passed through untouched |
| Positional paths (`a.$.b`, `a.$[el].b`)                                                        | ❌                                                             | ✅                          |
| Writing a `*__bidx` helper field directly                                                      | ❌                                                             | —                           |

Assigning a whole subtree (`$set: { profile: { … } }`) is supported: the operand
is traversed and every configured descendant is encrypted, with digests placed
inside the assigned subtree when they live there.

`$addToSet` is deliberately rejected when an added value contains an encrypted
descendant. AES-GCM uses a fresh random IV for every value, so two equal
plaintext values become different envelopes; passing the rewritten operation to
MongoDB would silently turn set insertion into ordinary append behavior. Use a
stable plaintext element identifier or an application-level read/compare/write
workflow with concurrency control.

## Reads

| Operation                                                                                 | Status | Notes                                         |
| ----------------------------------------------------------------------------------------- | ------ | --------------------------------------------- |
| `findOne`                                                                                 | ✅     |                                               |
| `find`                                                                                    | ✅     | Returns a decrypting cursor.                  |
| Cursor `next` / `tryNext` / `hasNext`                                                     | ✅     |                                               |
| Cursor `toArray` / `forEach`                                                              | ✅     |                                               |
| `for await (… of cursor)`                                                                 | ✅     |                                               |
| Cursor `stream()`                                                                         | ✅     | Decrypted documents.                          |
| Cursor `map()`                                                                            | ✅     | Applied after decryption.                     |
| Cursor `close` / `rewind` / `closed`                                                      | ✅     |                                               |
| Chained `sort`, `limit`, `skip`, `project`, `batchSize`, `hint`, `collation`, `maxTimeMS` | ⚠️     | Validated at the call site; see restrictions. |
| `countDocuments`                                                                          | ✅     | Filter rewritten.                             |
| `estimatedDocumentCount`                                                                  | ✅     | No filter involved.                           |
| `distinct` on a plaintext field                                                           | ✅     | Filter rewritten.                             |
| `distinct` on an encrypted field or digest                                                | ❌     | `EncryptedFieldQueryNotSupportedError`        |
| `aggregate`                                                                               | ⚠️     | Restricted stage list; see below.             |
| `createIndex` on plaintext or a digest field                                              | ✅     |                                               |
| `createIndex` on an encrypted path                                                        | ❌     | `EncryptedFieldSortNotSupportedError`         |
| `indexes`, `dropIndex`                                                                    | ✅     |                                               |

Blind-index helper fields are removed from every returned document.

## Filters

| Filter                                                 | On a blind-indexed field                                  | On an encrypted field without a blind index |
| ------------------------------------------------------ | --------------------------------------------------------- | ------------------------------------------- |
| `{ field: value }`                                     | ✅ rewritten to the digest                                | ❌                                          |
| `{ field: { $eq: value } }`                            | ✅                                                        | ❌                                          |
| `{ field: { $in: [...] } }`                            | ✅                                                        | ❌                                          |
| `{ field: { $exists: … } }`                            | ✅ passes through                                         | ✅                                          |
| `$and`, `$or`, `$nor` containing the above             | ✅ recursive                                              | —                                           |
| `$ne`, `$nin`                                          | ❌                                                        | ❌                                          |
| `$gt`, `$gte`, `$lt`, `$lte`                           | ❌                                                        | ❌                                          |
| `$regex`, `$text`, substring search                    | ❌                                                        | ❌                                          |
| `$not`, `$type`, `$mod`, `$size`, `$all`, `$elemMatch` | ❌                                                        | ❌                                          |
| A path inside an envelope (`body.ct`)                  | ❌                                                        | ❌                                          |
| A `*__bidx` field queried directly                     | ❌                                                        | —                                           |
| An ancestor of an encrypted field                      | ⚠️ `$exists` only                                         | —                                           |
| `$expr`, `$where`, `$jsonSchema`                       | ❌ on any configured collection — they cannot be analyzed |

`$ne` and `$nin` are rejected rather than approximated: a "not equal" over a
blind index would also exclude documents that have not been migrated yet, and
would silently answer a different question during a rollout.

### Query policy

| `queryPolicy` | Equality on a blind-indexed field becomes                                                                                                                                                 |
| ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `mixed`       | `{ $and: [{ $or: [{ email__bidx: <digest> }, { email: <value> }] }] }` — matches migrated _and_ unmigrated documents. Surrounding conditions, including an existing `$or`, are preserved. |
| `encrypted`   | `{ email__bidx: <digest> }` — required after verification.                                                                                                                                |

## Sorting, projection, hints, collation

| Request                                                    | Status                                                                                             |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `sort` on a plaintext field                                | ✅                                                                                                 |
| `sort` on an encrypted field or a digest                   | ❌ `EncryptedFieldSortNotSupportedError`                                                           |
| Projection including or excluding a whole configured field | ✅                                                                                                 |
| Projection of part of an envelope (`body.ct`)              | ❌ `EncryptedProjectionNotSupportedError`                                                          |
| Projection including a `*__bidx` field                     | ❌                                                                                                 |
| `$slice`, `$elemMatch`, `$meta` on a configured field      | ❌                                                                                                 |
| `hint` by index name                                       | ✅                                                                                                 |
| `hint` by key pattern referencing a protected field        | ❌                                                                                                 |
| `collation` with a filter on plaintext only                | ✅                                                                                                 |
| `collation` with a filter on an encrypted field            | ❌ — blind-index equality compares digests byte for byte, so a collation would change the question |

## Aggregation

Permitted stages on a configured collection: `$match` (rewritten with the filter
rules above), `$sort`, `$skip`, `$limit`, and `$project` restricted to plain
inclusion or exclusion.

Every other stage is rejected with `EncryptedAggregationNotSupportedError`,
including `$group`, `$lookup`, `$graphLookup`, `$replaceRoot`, `$replaceWith`,
`$set`, `$addFields`, `$unset`, `$unwind`, `$redact`, `$function`, `$where`,
`$count`, and any stage the analyzer does not recognise.

Because none of the permitted stages can move a value, a configured path in the
output is still the same configured path, so results can be decrypted. There is
no best-effort mode: a pipeline is either provably safe or rejected.

## Sessions and transactions

| Behaviour                                          | Status                                                                        |
| -------------------------------------------------- | ----------------------------------------------------------------------------- |
| Passing a `ClientSession` to a supported operation | ✅ unchanged                                                                  |
| Participating in a caller's transaction            | ✅ — encryption happens before the operation, so it is part of that operation |
| The wrapper creating implicit transactions         | Never                                                                         |
| Migration requiring transactions                   | Never — each document's values and digests land in one atomic update          |

## Raw access

`getRawDb()` and `getRawCollection()` require `allowRawAccess: true` and bypass
every guarantee: reads return envelopes and helper fields, writes are not
encrypted and get no digests. The CLI uses a private internal adapter and does
not need this flag.

## Not supported in version 1

GridFS stream encryption · `connect-mongo` session documents · change streams ·
Queryable Encryption or MongoDB CSFLE interop · Mongoose middleware · range,
substring, regex, or full-text search over encrypted values · sorting by
encrypted values · vector-database payloads.
