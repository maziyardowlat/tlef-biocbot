# Threat model

## The statement that matters

> A person with only MongoDB access cannot decrypt protected fields. A person who
> compromises both the authorized application and the required encryption keys
> may decrypt them, because the application must possess those keys to use the
> data.

Application-layer encryption moves the secret out of the database and into the
application's key provider. It does not make the data unreadable to the
application — the application has to read it to work.

## What this design defends against

For fields declared in the configuration:

### Disclosure

| Attacker capability                                                                              | Outcome                                                            |
| ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------ |
| Has the MongoDB connection string or a database user                                             | Sees envelopes: algorithm, key id, IV, tag, ciphertext. No values. |
| Reads the data through Compass, `mongosh`, or a driver                                           | Same.                                                              |
| Copies a `mongodump` or logical backup                                                           | Same, provided the keys are not stored with the backup.            |
| Copies the data directory or a storage snapshot                                                  | Same.                                                              |
| Receives raw documents accidentally (a log line, a support export, a screenshot of a collection) | Same.                                                              |

The defence is AES-256-GCM with a key that never enters MongoDB. There is no
fallback key and no package-level default key, so there is nothing to guess.

### Integrity and relocation

| Attacker capability                                                | Outcome                                                                                                    |
| ------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------- |
| Flips bits in the ciphertext                                       | Tag verification fails; `AuthenticationFailedError`.                                                       |
| Modifies the IV or the tag                                         | Same.                                                                                                      |
| Rewrites the key id to another known key                           | Fails: either the key id does not match the envelope's own AAD, or authentication fails.                   |
| Copies a valid value into a different field of the same collection | Fails: the configured field path is authenticated.                                                         |
| Copies a valid value into a different collection                   | Fails: the collection name is authenticated.                                                               |
| Copies a valid value into another application's namespace          | Fails: the namespace is authenticated.                                                                     |
| Replaces an envelope with a plausible-looking object               | Any object carrying `__ubc_enc` must parse and authenticate; a malformed one is an error, never plaintext. |
| Supplies an envelope through the application's own API             | Rejected: application writes containing envelopes raise `EnvelopeValidationError`.                         |

The defence is GCM's authentication tag plus deterministic AAD binding
`namespace`, `collection`, canonical `field` path, envelope version, algorithm,
and key id.

### Residual: same collection, same field, different document

Document `_id` is deliberately not authenticated. An attacker with **write**
access to MongoDB could move a ciphertext from one document to another document
of the same collection and field — for example, swapping two students' encrypted
notes.

This is accepted because including `_id` would prevent encrypting before an
insert assigns an id, force a read before every update, and break legitimate id
changes during a controlled migration. An attacker who can already write
arbitrary documents can also copy whole documents, so the marginal capability is
small. It is documented rather than hidden.

## What this design does not defend against

| Not defended                                                                   | Why                                                                                                                     |
| ------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------- |
| Compromise of the application runtime **and** its key provider                 | The application must hold the keys to use the data.                                                                     |
| Authorized application behaviour returning plaintext to the wrong user         | This is authorization, not encryption.                                                                                  |
| Plaintext in logs, traces, metrics, caches, exports, or third-party calls      | Those paths never touch the wrapper.                                                                                    |
| Memory inspection of a process that is actively decrypting                     | Plaintext exists in memory while in use. `dispose()` is best effort; JavaScript cannot guarantee removal of every copy. |
| Unconfigured collections and fields                                            | Nothing is protected implicitly.                                                                                        |
| Data copied to another datastore before encryption                             | Out of scope by construction.                                                                                           |
| Equality and frequency analysis of blind-indexed values                        | Inherent to any deterministic searchable index.                                                                         |
| Denial of service, availability, or database-level tampering that deletes data | Out of scope.                                                                                                           |

## Blind-index leakage in detail

A blind index is `HMAC-SHA-256(key, normalize(value))`, stored as
`bi1:<key-id>:<base64url digest>`.

**Cannot** be reversed without the key: an attacker holding only the database
cannot compute a digest for a guessed value, so they cannot even confirm a guess.

**Can** be observed with only database access:

- Which documents share a normalized value (identical digests).
- The frequency distribution of values (group sizes).

For a high-cardinality identifier such as an email address, learning "these two
records refer to the same person" is usually already implied by the data model.
For a low-cardinality field — a role with five values, a boolean, a small status
enum — frequency analysis effectively de-anonymizes the column: the largest group
is the most common value. **Do not blind-index low-cardinality values.**

If an attacker later obtains the blind-index key, they can test guessed values
offline against stored digests. This is why the blind-index key is separate from
the data-encryption key: compromising one does not automatically give the other.

## Key separation requirements

| Key                 | Purpose                           | Must differ from                                                    |
| ------------------- | --------------------------------- | ------------------------------------------------------------------- |
| Data-encryption key | AES-256-GCM for field values      | The blind-index key, and any existing API-credential encryption key |
| Blind-index key     | HMAC-SHA-256 for equality digests | Every data-encryption key (enforced at runtime)                     |

Reusing an existing API-key-encryption secret would mean one compromise exposes
both LLM credentials and student data, and would tie the rotation schedules of
two unrelated systems together.

## Operational assumptions

The design assumes the deploying institution provides:

- Key storage separate from MongoDB credentials and from database backups.
- A tested restore procedure (the CLI can require an operator to confirm a backup
  exists; it cannot verify one).
- Transport encryption, database authentication and authorization, and disk
  encryption. This package complements those; it replaces none of them.
- Access control over the trusted configuration module, which is executed by the
  CLI and can contain a connection factory and custom normalizer functions.

## What a security reviewer should look at

The cryptographic surface is deliberately small:

| File                       | Responsibility                                         |
| -------------------------- | ------------------------------------------------------ |
| `src/crypto/aad.ts`        | Deterministic AAD construction                         |
| `src/crypto/envelope.ts`   | Envelope format, strict parsing, fail-closed behaviour |
| `src/crypto/cipher.ts`     | AES-256-GCM seal/open, BSON wrapping                   |
| `src/crypto/blindIndex.ts` | HMAC digests and constant-time comparison              |
| `src/crypto/normalize.ts`  | Normalization before hashing                           |
| `src/keys/*`               | Key validation, decoding, providers                    |

`tests/security/security.test.ts` contains the attacks: envelope injection,
plaintext downgrade, ciphertext relocation, forged envelopes, prototype
pollution, secret exposure in formatted output, and malformed key material.
