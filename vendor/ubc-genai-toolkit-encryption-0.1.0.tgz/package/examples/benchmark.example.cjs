/**
 * Example benchmark workloads.
 *
 * Every document here is synthetic and clearly labelled. Replace these
 * workloads with your application's real query shapes - the point of the
 * harness is to measure *your* operations, not a generic crypto microbenchmark.
 *
 * Run with:
 *   npx ubc-genai-encryption benchmark \
 *     --config ./encryption.config.js \
 *     --workloads ./benchmark.workloads.js \
 *     --synthetic-data-confirmed
 */

'use strict';

const { syntheticText } = require('ubc-genai-toolkit-encryption');

const NOTES = 'sample_private_notes';
const PEOPLE = 'sample_people';

/** Builds a synthetic note. Nothing here resembles real data. */
function syntheticNote(iteration) {
  return {
    courseId: `SAMPLE-${100 + (iteration % 9)}`,
    createdAt: new Date(),
    synthetic: true,
    body: `synthetic note ${iteration}: ${syntheticText(240, iteration)}`,
    messages: [
      { role: 'learner', content: `synthetic question ${iteration}` },
      { role: 'assistant', content: `synthetic answer ${iteration}` },
    ],
  };
}

/** Builds a synthetic person with a high-cardinality lookup value. */
function syntheticPerson(iteration) {
  return {
    email: `synthetic.person.${iteration}@example.invalid`,
    cohort: `cohort-${iteration % 5}`,
    synthetic: true,
    profile: { displayName: `Synthetic Person ${iteration}` },
  };
}

const SEED_COUNT = 500;

module.exports.workloads = [
  {
    name: 'single-insert',
    description: 'One note inserted per operation.',
    collections: [NOTES],
    async run({ db, iteration }) {
      await db.collection(NOTES).insertOne(syntheticNote(iteration));
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'batch-insert-25',
    description: 'Twenty-five notes inserted per operation.',
    collections: [NOTES],
    async run({ db, iteration }) {
      const batch = Array.from({ length: 25 }, (_, index) => syntheticNote(iteration * 25 + index));
      await db.collection(NOTES).insertMany(batch);
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'find-by-plaintext-metadata',
    description: 'Indexed lookup on an unencrypted metadata field.',
    collections: [NOTES],
    async setup({ db, rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
      await rawDb.collection(NOTES).createIndex({ courseId: 1 });
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(NOTES).insertOne(syntheticNote(i));
      }
    },
    async run({ db, iteration }) {
      await db.collection(NOTES).findOne({ courseId: `SAMPLE-${100 + (iteration % 9)}` });
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'find-by-blind-indexed-equality',
    description: 'Equality lookup on an encrypted field that has a blind index.',
    collections: [PEOPLE],
    async setup({ db, rawDb }) {
      await rawDb.collection(PEOPLE).deleteMany({ synthetic: true });
      await rawDb
        .collection(PEOPLE)
        .createIndex(
          { [db === rawDb ? 'email' : 'email__bidx']: 1 },
          { name: db === rawDb ? 'sample_benchmark_email' : 'sample_benchmark_email_bidx' },
        );
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(PEOPLE).insertOne(syntheticPerson(i));
      }
    },
    async run({ db, iteration }) {
      await db
        .collection(PEOPLE)
        .findOne({ email: `synthetic.person.${iteration % SEED_COUNT}@example.invalid` });
    },
    async teardown({ rawDb }) {
      await rawDb.collection(PEOPLE).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'cursor-to-array-encrypted-content',
    description: 'Fifty documents materialized through the decrypting cursor.',
    collections: [NOTES],
    async setup({ db, rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(NOTES).insertOne(syntheticNote(i));
      }
    },
    async run({ db }) {
      await db.collection(NOTES).find({ synthetic: true }).limit(50).toArray();
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'update-one-encrypted-field',
    description: 'Single-document update of one encrypted field.',
    collections: [NOTES],
    async setup({ db, rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(NOTES).insertOne(syntheticNote(i));
      }
    },
    async run({ db, iteration }) {
      await db
        .collection(NOTES)
        .updateOne(
          { courseId: `SAMPLE-${100 + (iteration % 9)}` },
          { $set: { body: `synthetic revision ${iteration}` } },
        );
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'sort-scan-plaintext-metadata',
    description: 'Range scan and sort over unencrypted metadata.',
    collections: [NOTES],
    async setup({ db, rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
      await rawDb.collection(NOTES).createIndex({ createdAt: -1 });
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(NOTES).insertOne(syntheticNote(i));
      }
    },
    async run({ db }) {
      await db
        .collection(NOTES)
        .find({ createdAt: { $lte: new Date() } })
        .sort({ createdAt: -1 })
        .limit(25)
        .toArray();
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },

  {
    name: 'full-export-through-wrapper',
    description: 'Whole-collection export through the decrypting wrapper.',
    collections: [NOTES],
    async setup({ db, rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
      for (let i = 0; i < SEED_COUNT; i += 1) {
        await db.collection(NOTES).insertOne(syntheticNote(i));
      }
    },
    async run({ db }) {
      let count = 0;
      for await (const document of db.collection(NOTES).find({ synthetic: true })) {
        count += document ? 1 : 0;
      }
      return count;
    },
    async teardown({ rawDb }) {
      await rawDb.collection(NOTES).deleteMany({ synthetic: true });
    },
  },
];
