/**
 * Example encryption configuration.
 *
 * Everything here is fabricated. `sample-learning-app`, `sample_private_notes`,
 * and `sample_people` are illustrations, not defaults, and this file must not be
 * copied into a real application without an application-specific field and query
 * audit: every field you protect is a field you can no longer sort, range-query,
 * or regex-search.
 *
 * Copy this file into your application, rename the namespace, and replace the
 * collections and fields with your own.
 */

'use strict';

const { defineEncryptionConfig, EnvironmentKeyProvider } = require('ubc-genai-toolkit-encryption');

module.exports = defineEncryptionConfig({
  /**
   * Stable identifier for this application. It is authenticated into every
   * ciphertext, so changing it makes existing data undecryptable.
   */
  namespace: 'sample-learning-app',

  /**
   * Keys come from environment variables named here. The *names* live in
   * configuration; the values are injected at deploy time from a secret file or
   * an institutional secret manager, and are stored separately from the MongoDB
   * credentials and from database backups.
   *
   * Generate independent keys, for example:
   *   node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
   *
   * The data-encryption key must not be the key already used to encrypt LLM or
   * API credentials, and the blind-index key must differ from both.
   */
  keyProvider: new EnvironmentKeyProvider({
    activeEncryptionKey: {
      id: 'data-2026-01',
      env: 'SAMPLE_DATA_ENCRYPTION_KEY',
    },
    // Retired keys stay listed until a rotation has been verified, so existing
    // envelopes remain readable.
    decryptionKeys: [],
    blindIndexKeys: [{ id: 'lookup-2026-01', env: 'SAMPLE_BLIND_INDEX_KEY' }],
  }),

  /**
   * Rollout policies. Start here (mixed reads and queries, encrypted writes),
   * then move to readPolicy 'strict' and queryPolicy 'encrypted' once
   * verification passes across every configured collection.
   */
  readPolicy: 'mixed',
  queryPolicy: 'mixed',
  writePolicy: 'encrypted',

  collections: {
    sample_private_notes: {
      fields: {
        // A whole scalar field.
        body: { encrypt: true },
        // Every element of an array of subdocuments.
        'messages.$[].content': { encrypt: true },
      },
    },

    sample_people: {
      fields: {
        // An identifier that must still support equality lookup. The blind index
        // makes findOne({ email }) work; it also leaks which documents share a
        // value, which is acceptable for a high-cardinality identifier and is not
        // acceptable for a role or status field.
        email: {
          encrypt: true,
          blindIndex: {
            field: 'email__bidx',
            keyId: 'lookup-2026-01',
            normalize: 'email',
            unique: true,
          },
        },
        'profile.displayName': { encrypt: true },
      },
    },
  },

  /**
   * Connection metadata for the CLI and the programmatic migration API. Only
   * environment-variable *names* appear here, never a literal URI.
   * `createEncryptedDb` ignores this member: it wraps the Db the application has
   * already connected.
   */
  database: {
    uriEnv: 'MONGODB_URI',
    databaseEnv: 'MONGODB_DB_NAME',
  },
});
